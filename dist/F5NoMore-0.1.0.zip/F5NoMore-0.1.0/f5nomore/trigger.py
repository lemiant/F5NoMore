import threading, time, SimpleHTTPServer, SocketServer
from watchdog.observers import Observer #pypi
import ws

SERVER_PORT = 8888
Handler = SimpleHTTPServer.SimpleHTTPRequestHandler

httpd = SocketServer.TCPServer(("", SERVER_PORT), Handler)

threading.Thread(target = httpd.serve_forever, args = ()).start()
print "Serving files at port", SERVER_PORT

threading.Thread(target = ws.start_server, args = ()).start()
print "Starting WebSocket..."

class handler(object):
   def dispatch(self, event):
      print "Caught"
      print event
      ws.broadcast("update")

observer = Observer()
observer.schedule(handler(), r"C:\Users\Alex\Dropbox\My Stuff\Programming\Reloaden", recursive=True)
observer.start()
print "Watching file system"

while 1:
   time.sleep(50)
